from .Functions import getChanges
from .Weblog import Weblog
__version__ = 1.0
